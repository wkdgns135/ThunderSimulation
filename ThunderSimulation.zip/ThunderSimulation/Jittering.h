#pragma once
#include "Global.h"
using namespace std;

void Jittering(int order, double(*chanelPos)[2], int w, int h);