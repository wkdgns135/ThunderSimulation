#pragma once
#include "Global.h"
#include "GL/glew.h"
#include "GL/glut.h"

extern const short int index;

void printProgramInfoLog(GLuint obj);
void printShaderInfoLog(GLuint obj);
int printOglError(char *file, int line);
void setShaders();
void initGLEW();
void initGL();
int textFileWrite(const char *fn, const char *s);
char *textFileRead(const char *fn);