#include "Surface.h"

Laplace Surface(Laplace laplace, int m_row, int m_col, double(*lattice)[index + 1], double(*chanelPos)[2]) {
	for (int i = 0; i < index; i++) {
		for (int j = 0; j <= index; j++) {
			lattice[i][j] = laplace.t;
		}
	}
	for (int i = 0; i <= index; i++) {
		lattice[index][i] = 1;
	}
	laplace.row = m_row;
	laplace.col = m_col;
	laplace.order = 0;

	lattice[m_row][m_col] = 0;

	chanelPos[laplace.order][0] = m_row;
	chanelPos[laplace.order][1] = m_col;

	return laplace;
}
