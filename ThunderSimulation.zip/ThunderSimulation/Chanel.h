#pragma once
#include "Laplace.h"
#include "Global.h"

Laplace MainChanel(Laplace laplace, double(*lattice)[index + 1], double(*mainChanelPos)[2]);