#pragma once
#include "Global.h"
#include "Laplace.h"

Laplace Surface(Laplace laplace, int m_row, int m_col, double(*lattice)[index + 1], double(*chanelPos)[2]);
